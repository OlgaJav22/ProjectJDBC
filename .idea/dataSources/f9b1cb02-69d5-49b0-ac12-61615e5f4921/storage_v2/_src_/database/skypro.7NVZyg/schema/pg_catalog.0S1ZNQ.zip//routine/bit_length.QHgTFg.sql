create function bit_length(bytea) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN (octet_length($1) * 8);

comment on function bit_length(bytea) is 'length in bits';

alter function bit_length(bytea) owner to postgres;

